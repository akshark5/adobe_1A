import fitz  # PyMuPDF
import re
from statistics import median
from collections import Counter

# Global Unicode script and punctuation support
MULTILINGUAL_REGEX = r'[a-zA-Z\u0900-\u097F\u0600-\u06FF\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF]'
MULTILINGUAL_END_PUNCTUATION = (':', '：', '。', '、', '。', '،')

def extract_with_mupdf(pdf_path):
    blocks = extract_blocks(pdf_path)
    title = find_title(blocks)
    outline = generate_outline(blocks, title)
    return {
        "title": title,
        "outline": outline
    }

def extract_blocks(pdf_path):
    doc = fitz.open(pdf_path)
    blocks = []
    for page_index, page in enumerate(doc):
        for block in page.get_text("dict")["blocks"]:
            if block["type"] != 0:
                continue
            for line in block["lines"]:
                text = " ".join(span["text"].strip() for span in line["spans"])
                if not text.strip():
                    continue
                span = line["spans"][0]
                blocks.append({
                    "text": text.strip(),
                    "font_size": round(span["size"], 2),
                    "font": span["font"].lower(),
                    "bold": bool(span["flags"] & 2**4) or "bold" in span["font"].lower(),
                    "page": page_index + 1,
                    "x": round(span["bbox"][0], 1),
                    "y": block["bbox"][1]
                })
    doc.close()
    return blocks

def merge_heading_lines(blocks, y_threshold=18, x_threshold=12):
    merged = []
    i = 0
    while i < len(blocks):
        current = blocks[i]
        line_group = [current]
        j = i + 1
        while j < len(blocks):
            next_block = blocks[j]
            same_style = (
                current["font_size"] == next_block["font_size"] and
                current["font"] == next_block["font"] and
                current["bold"] == next_block["bold"] and
                current["page"] == next_block["page"] and
                abs(next_block["y"] - line_group[-1]["y"]) <= y_threshold and
                abs(next_block["x"] - current["x"]) <= x_threshold
            )
            if same_style:
                line_group.append(next_block)
                j += 1
            else:
                break
        merged.append({
            "text": " ".join(b["text"] for b in line_group).strip(),
            "font_size": current["font_size"],
            "font": current["font"],
            "bold": current["bold"],
            "page": current["page"],
            "y": current["y"],
            "x": current["x"]
        })
        i = j
    return merged

def find_title(blocks):
    first_page_blocks = [b for b in blocks if b["page"] == 1 and b["y"] < 300]
    if not first_page_blocks:
        return "Untitled Document"
    largest_font = max(b["font_size"] for b in first_page_blocks)
    title_lines = [
        b for b in first_page_blocks
        if b["font_size"] >= largest_font - 1
        and 3 <= len(b["text"].split()) <= 25
        and not any(p in b["text"].lower() for p in ["@", ".com", "www.", "page", "doi"])
    ]
    title_lines.sort(key=lambda b: b["y"])
    merged_lines = merge_heading_lines(title_lines)
    merged_lines.sort(key=lambda g: (-len(g["text"]), g["y"]))
    return merged_lines[0]["text"] if merged_lines else "Untitled Document"


def assign_heading_level(text, font_size, size_rank):
    if re.match(r"^\d+\.\d+\.\d+", text): return "H3"
    if re.match(r"^\d+\.\d+", text): return "H2"
    if re.match(r"^\d+\.", text): return "H1"
    if size_rank == 0: return "H1"
    if size_rank == 1: return "H2"
    return "H3"

def multilingual_safe_score(text, font_size, bold, body_size, next_block=None):
    score = 0
    word_count = len(text.split())

    if font_size > body_size: score += 2
    if font_size >= body_size * 1.3: score += 2
    if bold: score += 1
    if re.match(r"^(\d+[\.\)]?)+", text): score += 1
    if text.endswith(MULTILINGUAL_END_PUNCTUATION): score += 1
    if word_count <= 6 and not text.endswith("."): score += 1

    if text.endswith(MULTILINGUAL_END_PUNCTUATION) and next_block:
        if not next_block["bold"] and next_block["font_size"] < font_size:
            score += 1

    return score

def is_cjk(text):
    return bool(re.search(r'[\u4E00-\u9FFF\u3040-\u30FF]', text))  # Chinese + Japanese

def generate_outline(blocks, title):
    blocks = merge_heading_lines(blocks)
    seen, headings = set(), []
    text_freq = Counter(b["text"].strip().lower() for b in blocks)
    body_size = median([b["font_size"] for b in blocks])
    size_levels = sorted({b["font_size"] for b in blocks if b["font_size"] > body_size})
    size_to_rank = {sz: i for i, sz in enumerate(size_levels)}

    for i, b in enumerate(blocks):
        text = b["text"]
        norm = text.lower().strip()

        if norm in seen or norm in ["", title.lower()] or text_freq[norm] > 2:
            continue
        if not re.search(MULTILINGUAL_REGEX, text): continue
        if len(text.split()) > 25: continue
        if is_cjk(text) and len(text) > 30: continue  # Skip long CJK lines (likely paragraphs)
        if re.match(r"^\d{1,2}/\d{1,2}/\d{2,4}", text): continue
        if any(keyword in norm for keyword in ["page", "copyright", "www.", "@"]): continue

        next_block = blocks[i+1] if i+1 < len(blocks) else None
        score = multilingual_safe_score(text, b["font_size"], b["bold"], body_size, next_block)

        if score >= 4:
            size_rank = size_to_rank.get(b["font_size"], 2)
            level = assign_heading_level(text, b["font_size"], size_rank)
            headings.append({
                "level": level,
                "text": text,
                "page": b["page"]
            })
            seen.add(norm)

    return headings
