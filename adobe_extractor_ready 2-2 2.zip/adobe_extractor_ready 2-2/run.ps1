# run.ps1
# Usage: Right-click > Run with PowerShell (or run in terminal)

Write-Host "`n📄 Starting PDF extractor..."
docker run --rm `
  -v "${PWD}\app\input:/app/app/input" `
  -v "${PWD}\app\output:/app/app/output" `
  pdf-extractor
Write-Host "`n✅ Extraction complete. Check the app/output folder."
